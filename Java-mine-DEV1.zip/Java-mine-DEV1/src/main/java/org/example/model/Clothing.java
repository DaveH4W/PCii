package org.example.model;

public class Clothing extends Product {
    public Clothing(String sku, String category, String name, String brand, double unitPrice, int quantity) {
        super(sku, category, name, brand, unitPrice, quantity);
    }
}

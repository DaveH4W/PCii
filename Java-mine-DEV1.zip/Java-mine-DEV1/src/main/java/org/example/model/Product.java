package org.example.model;

public abstract class Product {
    protected String sku;
    protected String category;
    protected String name;
    protected String brand;
    protected double unitPrice;
    protected int quantity;

    public Product(String sku, String category, String name, String brand, double unitPrice, int quantity) {
        this.sku = sku;
        this.category = category;
        this.name = name;
        this.brand = brand;
        this.unitPrice = unitPrice;
        this.quantity = quantity;
    }

    // Getters
    public String getSku() { return sku; }
    public String getCategory() { return category; }
    public String getName() { return name; }
    public String getBrand() { return brand; }
    public double getUnitPrice() { return unitPrice; }
    public int getQuantity() { return quantity; }

    @Override
    public String toString() {
        return sku + " | " + category + " | " + name + " | " + brand + " | " + unitPrice + " | " + quantity;
    }
}

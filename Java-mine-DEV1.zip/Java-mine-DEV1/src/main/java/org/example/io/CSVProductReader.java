package org.example.io;

import org.example.model.Clothing;
import org.example.model.Electronics;
import org.example.model.Product;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class CSVProductReader{
    /**
     * Reads Electronics products from a CSV file in the resources folder.
     *
     * @param csvFile path relative to resources, e.g., "electronics/Electronics.csv"
     * @return List of Electronics products
     */
    public static List<Product> readElectronics(String csvFile) {
        return readProducts(csvFile, "Electronics");
    }

    /**
     * Reads Clothing products from a CSV file in the resources folder.
     *
     * @param csvFile path relative to resources, e.g., "clothing/Clothing.csv"
     * @return List of Clothing products
     */
    public static List<Product> readClothing(String csvFile) {
        return readProducts(csvFile, "Clothing");
    }

    /**
     * Generic method to read products from CSV, validate, and produce Product subclasses.
     *
     * @param csvFile path relative to resources
     * @param type    "Electronics" or "Clothing"
     * @return List of valid products
     */
    private static List<Product> readProducts(String csvFile, String type) {
        List<Product> products = new ArrayList<>();

        try {
            InputStream is = CSVProductReader.class.getClassLoader().getResourceAsStream(csvFile);
            if (is == null) {
                throw new RuntimeException("Resource not found: " + csvFile);
            }

            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String line;
            boolean firstLine = true;

            while ((line = br.readLine()) != null) {
                if (firstLine) { // skip header
                    firstLine = false;
                    continue;
                }

                String[] fields = line.split(",");
                if (fields.length < 6) {
                    System.out.println("Skipping incomplete record (not enough columns): " + line);
                    continue;
                }

                // Trim and extract fields
                String sku = fields[0].trim();
                String category = fields[1].trim();
                String name = fields[2].trim();
                String brand = fields[3].trim();
                String unitPriceStr = fields[4].trim();
                String quantityStr = fields[5].trim();

                // Validate mandatory fields
                if (sku.isEmpty() || category.isEmpty() || name.isEmpty() || brand.isEmpty()) {
                    System.out.println("Skipping incomplete record (missing mandatory fields): " + line);
                    continue;
                }

                // Parse numeric fields
                double unitPrice;
                int quantity;
                try {
                    unitPrice = Double.parseDouble(unitPriceStr);
                    quantity = Integer.parseInt(quantityStr);
                } catch (NumberFormatException e) {
                    System.out.println("Skipping invalid number record: " + line);
                    continue;
                }

                // Create product object
                Product product;
                if (type.equals("Electronics")) {
                    product = new Electronics(sku, category, name, brand, unitPrice, quantity);
                } else { // Clothing
                    product = new Clothing(sku, category, name, brand, unitPrice, quantity);
                }

                products.add(product);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return products;
    }
}

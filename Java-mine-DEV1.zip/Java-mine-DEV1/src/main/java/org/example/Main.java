package org.example;

import org.example.io.CSVProductReader;
import org.example.model.Product;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        // In-memory product lists
        List<Product> electronicsList = new ArrayList<>();
        List<Product> clothingList = new ArrayList<>();

        boolean exit = false;

        while (!exit) {
            // Display menu
            System.out.println("\n==== Inventory System ====");
            System.out.println("1. Import Electronics CSV");
            System.out.println("2. Import Clothing CSV");
            System.out.println("3. Display Electronics");
            System.out.println("4. Display Clothing");
            System.out.println("5. Exit");
            System.out.print("Select option: ");

            int option;
            try {
                option = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input, please enter a number 1-5.");
                continue;
            }

            switch (option) {
                case 1:
                    // Import Electronics CSV
                    try {
                        List<Product> importedElectronics = CSVProductReader.readElectronics("electronics/Electronics.csv");
                        electronicsList.clear();
                        electronicsList.addAll(importedElectronics);
                        System.out.println("Imported " + importedElectronics.size() + " electronics products.");
                    } catch (Exception e) {
                        System.out.println("Error importing electronics CSV: " + e.getMessage());
                    }
                    break;

                case 2:
                    // Import Clothing CSV
                    try {
                        List<Product> importedClothing = CSVProductReader.readClothing("clothing/Clothing.csv");
                        clothingList.clear();
                        clothingList.addAll(importedClothing);
                        System.out.println("Imported " + importedClothing.size() + " clothing products.");
                    } catch (Exception e) {
                        System.out.println("Error importing clothing CSV: " + e.getMessage());
                    }
                    break;

                case 3:
                    // Display Electronics
                    if (electronicsList.isEmpty()) {
                        System.out.println("No electronics products imported yet.");
                    } else {
                        System.out.println("\n--- Electronics Products ---");
                        electronicsList.forEach(System.out::println);
                    }
                    break;

                case 4:
                    // Display Clothing
                    if (clothingList.isEmpty()) {
                        System.out.println("No clothing products imported yet.");
                    } else {
                        System.out.println("\n--- Clothing Products ---");
                        clothingList.forEach(System.out::println);
                    }
                    break;

                case 5:
                    // Exit
                    System.out.println("Exiting Inventory System. Goodbye!");
                    exit = true;
                    break;

                default:
                    System.out.println("Invalid option, please enter a number 1-5.");
            }
        }

        scanner.close();
    }
}
